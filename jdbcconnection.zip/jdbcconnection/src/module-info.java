/**
 * 
 */
/**
 * @author MSIS
 *
 */
module jdbcconnection {
	requires java.sql;
	requires org.apache.logging.log4j;
}